# BDD_SQL
Créez et utilisez une base de données immobilière avec SQL
Data analyst dans un réseau national d’agences immobilières. Le directeur général est sensible depuis quelque temps à l’importance des données, et il pense que l’agence doit 
se démarquer de la concurrence en créant un modèle pour mieux prévoir le prix de vente des biens immobiliers. 
Réalisez:

Dictionnaire des données.

Schéma relationnel normalisé modifié. 

Base de données opérationnelle avec les données du 1er semestre 2020 (captures d’écran directement du système de gestion de base de données des tables construites).

Document avec les requêtes et les résultats (PDF). 
