# Indicateur_-galit-_femme-homme
Analysez des indicateurs de l'égalité femme-homme avec Knime

Vous êtes data analyst dans un cabinet de consultant spécialisé dans la transformation digitale des entreprises. Le cabinet compte déjà plus de 150 salariés
et est en plein développement. 
Dans ce contexte économique, le recrutement de consultants expérimentés devient un véritable enjeu stratégique.
Chaque année avant le 1er mars, les entreprises d’au moins 50 salariés doivent calculer et publier sur leur site Internet leur index de l’égalité 
femmes-hommes.
Pour créer cet index,j'ai mis à disposition le fichier csv généré , le powerpoint de présentation que j'ai réalisé ainsi que le workflow généré avec KNIME.
