# Etude_santé_publique-avec-R
Réalisez une étude de santé publique avec R ou Python
Aider à construire un monde libéré de la faim . 
