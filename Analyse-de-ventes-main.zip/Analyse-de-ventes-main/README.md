# Analyse-de-ventes
Faites une analyse des ventes pour un e-commerce
Travail en tant que Data Analyst au service Marketing d'une entreprise de grande distribution dans plusieurs secteurs (nourriture, biens de consommation 
et high tech). 
Elle gère un entrepôt et livre à domicile les commandes effectuées par les clients sur son site Internet.

Mission 1 : Vérification et présentation des graphiques

Mission 2 : Analyse des données de clients affiliés
